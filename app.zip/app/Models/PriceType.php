<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PriceType extends Model
{
    protected $fillable = [
        'code',
        'name',
        'price',
        'active',
    ];
}