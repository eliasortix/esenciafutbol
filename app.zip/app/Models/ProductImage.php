<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductImage extends Model
{
    protected $fillable = [
        'product_id',
        'path',
        'position',
        'alt_text',
    ];

    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}